#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Bisection Method -- HOMEWORK
**********************************************/
void program1_3(FILE *fp)
{
	double a0, b0, x0, x1 , temp;
	int n;

	printf("Enter a0, b0: ");
	scanf("%lf %lf", &a0, &b0);

	while (_f(a0) * _f(b0) >=0) {
		printf("The conditions are not satisfied. Make f(a0)*f(b0) <0\n ");
		printf("Enter a0, b0: ");
		scanf("%lf %lf", &a0, &b0);
	}

	fprintf(fp, "  i                 xn1                              | f(xn1) |\n");

	n = 0;
	x0 = a0;

	for (n; n <= Nmax; n++) {
		x1 = (a0 + b0) / 2;
		if (fabs(_f(x1)) < DELTA && fabs(x1-x0) < EPSILON) {
			break;
		}
		fprintf(fp, "%3d    %.15e    %.15e\n", n, x1, fabs(_f(x1)));
		if (_f(a0) * _f(x1) < 0)  b0 = x1; // [ a0, x1 ]
		else if(_f(b0) * _f(x1) < 0) {
			a0 = x1; // [x1, b0]
		}
		else {
			break;
		}
		x0 = x1;
	}


}